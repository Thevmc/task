const express=require("express");
const product=require('../model/user');
const {isvaliddiscount,isvalidpid,isvalidpname,isvalidprice}=require('../validators/validate')
async function register(req,res)
{
    try
    {
        const details=req.body
        const err=[];

        if(Object.keys(details).length==0)
        {
            return res.status(400).json({status:"error",message:"all feilds are required.."});
        }

        const {pid,pname,price,discount,...rest}=req.body;
        if(Object.keys(rest).length>0)
        {
            return res.status(400).json({error:`remove ${Object.keys(rest)} from the body.`})
        }

        const productset=["pid","pname","price","discount"];
        for(feild of productset)
        {
            if(!details.hasOwnProperty(feild))
            {
                return res.status(400).json({error:`invalid  this ${feild} is required in the body`})
            }

            if(feild==="pid")
            {
                if(!isvalidpid(details[feild]))
                {
                    err.push(`${feild} should only contain integers`);
                    continue;
                }
            }
            if(feild==="pname")
            {
                if(!isvalidpname(details[feild]))
                {
                    err.push(`${feild} should contains only integers`)
                }
            }
            if(feild==="price")
            {
                if(!isvalidprice(details[feild]))
                {
                    err.push(`${feild} should contain only the integers`)
                }
            }
            if(feild==="discount")
            {
                if(!isvaliddiscount(details[feild]))
                {
                    err.push(`${feild} should be in correct format`)
                }
            }

        }

        // if (err.length > 0) {
        //     return res.status(400).send({
        //         status: false,
        //         message: err.join(", "),
        //     });
        // }
        let results=await product.findOne(
            {
            where:{pid:details.pid}
            });
        if(results)
                {
                    return res.status(400).json({message:"already registered"})
                }

        const result=await product.create({pid,pname,price,discount});
        return res.json({result:result});

    }
    catch(err)
    {
        console.log(err);
    }
}


async function getalldetails(req,res)
{
    try
    {
        const getall=await product.findAll({});
        if(!getall)
        {
            return res.send("no data found in the database");
        }
        return res.status(200).json({Allproducts:getall});

    }
    catch(err)
    {
        console.log(err);
    }
}
module.exports={register,getalldetails}