const express=require("express")
const router=express.Router();
const {register,getalldetails}=require('../controllers/product')
router.route('/register').post(register);
router.route('/products').get(getalldetails);
module.exports=router;