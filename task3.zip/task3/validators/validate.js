function isvalid(value)
{
    if(value!==String || value.trim.length()==0)
    {
        return false;
    }
    else{
        return true;
    }
}

function isvalidpid(value)
{                                                     
    let pidregrex=/^([0-9]{10})*$/;
    return pidregrex.test(value);


}
function isvalidpname(value)
{
    let pnameregrex=/^[a-zA-Z]+$/;
    return pnameregrex.test(value)
}
 function isvalidprice(value)
 {
    let priceregrex=/^([0-9]{10})*$/;
    return priceregrex.test(value);
 }

 function isvaliddiscount(value)
 {
    let disregrex=/^([0-9]{10})*$/;
    return disregrex.test(value);
 }

 module.exports={isvalid,isvalidpid,isvaliddiscount,isvalidpname,isvalidprice}