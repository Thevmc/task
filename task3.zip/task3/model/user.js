const { DataTypes } = require('sequelize')
const {sequelize}=require('../connections')
const user=sequelize.define('user',{
    pid:{
        type:DataTypes.INTEGER,
        allownull:false,
        autoincrement:true,
        primarykey:true
    },
    pname:{
        type:DataTypes.STRING,
        allownull:false,
    },
    price:{
        type:DataTypes.INTEGER,
        allownull:false,
        
    },
    discount:{
        type:DataTypes.INTEGER,
        allownull:true,
    }
})
sequelize.sync();
module.exports=user